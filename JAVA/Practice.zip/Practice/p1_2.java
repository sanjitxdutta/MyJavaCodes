import java.util.Scanner;

public class p1_2 {
    public static void main(String [] Args){
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        String age = sc.nextLine();

        System.out.println(name + ":" + age);
    }
}
