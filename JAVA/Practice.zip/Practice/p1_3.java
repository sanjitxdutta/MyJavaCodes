import java.util.Scanner;

class area{
    
}

public class p1_3 {
    public static void main(String [] args){
        
    }
}